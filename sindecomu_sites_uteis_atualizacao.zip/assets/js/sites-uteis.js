/* SINDECOMU | Diretório de Sites Úteis. Lê dados externos, sem links no HTML. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const svg = id => `<svg class="ico" aria-hidden="true"><use href="#${id}"></use></svg>`;
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const validExternal = value => { try { const u=new URL(value); return u.protocol==='https:' ? u.href : null; } catch { return null; }};
  const norm = v => String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
  const categories = ['Todos','Documentos','Benefícios','Previdência','Emprego','Direitos e Justiça','Empregadores'];
  let links = Array.isArray(window.SINDECOMU_LINKS_UTEIS) ? window.SINDECOMU_LINKS_UTEIS : [];
  let active = 'Todos';
  function siteHeader() {
    const menu=$('mobileNav'), toggle=$('menuToggle'), symbol=$('menuIcon'), head=document.querySelector('.site-header'), hero=document.querySelector('.ul-hero');
    function menuSet(value){menu.classList.toggle('open',value);toggle.setAttribute('aria-expanded',String(value));toggle.setAttribute('aria-label',value?'Fechar menu':'Abrir menu');symbol?.setAttribute('href',value?'#i-close':'#i-menu')}
    toggle?.addEventListener('click',()=>menuSet(!menu.classList.contains('open')));
    menu?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>menuSet(false)));
    window.addEventListener('resize',()=>{if(window.innerWidth>980)menuSet(false)});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')menuSet(false)});
    const font=$('fontSize'); font?.addEventListener('click',()=>{const on=document.body.classList.toggle('lg-text');font.textContent=on?'A−':'A+';font.setAttribute('aria-pressed',String(on))});
    let queued=false;
    function update(){queued=false; if(hero) head?.classList.toggle('is-after-hero',hero.getBoundingClientRect().bottom <= (head?.offsetHeight||80)+2)}
    window.addEventListener('scroll',()=>{if(!queued){queued=true;requestAnimationFrame(update)}},{passive:true});window.addEventListener('resize',update);update();
  }
  function observers(){const nodes=document.querySelectorAll('.ul-reveal');if(!('IntersectionObserver' in window)){nodes.forEach(n=>n.classList.add('is-visible'));return} const io=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}})},{threshold:0.06});nodes.forEach(n=>io.observe(n))}
  function card(data,featured=false){const url=validExternal(data.url);if(!url)return '';const h=escapeHTML,icon=svg(data.icone||'u-globe');if(featured){return `<a class="ul-feature-card" href="${h(url)}" target="_blank" rel="noopener noreferrer" aria-label="Abrir ${h(data.titulo)} em outra aba"><span class="ul-card-icon">${icon}</span><h3>${h(data.titulo)}</h3><p>${h(data.descricao)}</p><span class="ul-card-foot">Acessar serviço ${svg('u-external')}</span></a>`}return `<a class="ul-service-card" href="${h(url)}" target="_blank" rel="noopener noreferrer" aria-label="Abrir ${h(data.titulo)} em outra aba"><span class="ul-service-header"><span class="ul-card-icon">${icon}</span><span class="ul-service-category">${h(data.categoria)}</span></span><h4>${h(data.titulo)}</h4><p>${h(data.descricao)}</p><span class="ul-service-action"><span>${h(data.fonte||'Serviço externo')}</span>${svg('u-external')}</span></a>`}
  function chips(){const group=$('linkCategories');group.innerHTML=categories.map(c=>`<button type="button" class="ul-chip" data-category="${escapeHTML(c)}" aria-pressed="${c===active}">${escapeHTML(c)}</button>`).join('')}
  function results(){const q=norm($('linkSearch').value).trim();const visible=links.filter(x=>(active==='Todos'||x.categoria===active)&&(!q||norm([x.titulo,x.descricao,x.categoria,...(x.palavras||[])].join(' ')).includes(q)));$('linkResults').innerHTML=visible.map(x=>card(x)).join('');$('emptyLinks').hidden=visible.length!==0;$('resultTitle').textContent=active==='Todos'?'Todos os serviços':active;$('resultCount').textContent=`${visible.length} ${visible.length===1?'serviço encontrado':'serviços encontrados'}`;$('clearSearch').hidden=!$('linkSearch').value;chips()}
  function reset(){active='Todos';$('linkSearch').value='';results()}
  function start(){siteHeader();observers();links=links.filter(x=>x&&x.titulo&&validExternal(x.url));$('featuredLinks').innerHTML=links.filter(x=>x.destaque).slice(0,3).map(x=>card(x,true)).join('');$('linkCategories').addEventListener('click',e=>{const btn=e.target.closest('button[data-category]');if(!btn)return;active=btn.dataset.category;results()});$('linkSearch').addEventListener('input',results);$('clearSearch').addEventListener('click',()=>{$('linkSearch').value='';$('linkSearch').focus();results()});$('resetLinks').addEventListener('click',reset);results()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start); else start();
})();
