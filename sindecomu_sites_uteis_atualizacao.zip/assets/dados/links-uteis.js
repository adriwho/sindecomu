/* Diretório demonstrativo. Futuramente consultar API/banco de dados. */
window.SINDECOMU_LINKS_UTEIS = [
  {
    "id": "ctps",
    "titulo": "Carteira de Trabalho Digital",
    "descricao": "Consulte vínculos empregatícios, contratos e anotações da sua vida profissional.",
    "categoria": "Documentos",
    "icone": "u-id",
    "url": "https://www.gov.br/pt-br/servicos/obter-a-carteira-de-trabalho",
    "fonte": "gov.br · Ministério do Trabalho",
    "destaque": true,
    "palavras": [
      "ctps",
      "carteira digital",
      "contrato",
      "vinculos"
    ]
  },
  {
    "id": "fgts",
    "titulo": "Extrato do FGTS",
    "descricao": "Acompanhe depósitos e saldo do Fundo de Garantia nos canais da Caixa.",
    "categoria": "Benefícios",
    "icone": "u-wallet",
    "url": "https://www.caixa.gov.br/beneficios-trabalhador/fgts/extrato-FGTS/Paginas/default.aspx",
    "fonte": "Caixa Econômica Federal",
    "destaque": true,
    "palavras": [
      "caixa",
      "fundo de garantia",
      "extrato",
      "depósitos"
    ]
  },
  {
    "id": "seguro",
    "titulo": "Seguro-Desemprego",
    "descricao": "Solicite o benefício e veja como acompanhar a análise e as parcelas.",
    "categoria": "Benefícios",
    "icone": "u-shield",
    "url": "https://www.gov.br/pt-br/servicos/solicitar-o-seguro-desemprego",
    "fonte": "gov.br · Serviço oficial",
    "destaque": true,
    "palavras": [
      "demissao",
      "desemprego",
      "parcela"
    ]
  },
  {
    "id": "abono",
    "titulo": "Abono Salarial",
    "descricao": "Consulte informações do benefício por meio dos serviços do Portal Emprega Brasil.",
    "categoria": "Benefícios",
    "icone": "u-wallet",
    "url": "https://www.gov.br/pt-br/servicos/acessar-portal-emprega-brasil-2013-trabalhador",
    "fonte": "gov.br · Emprega Brasil",
    "palavras": [
      "pis",
      "pasep",
      "abono",
      "beneficio"
    ]
  },
  {
    "id": "inss",
    "titulo": "Meu INSS",
    "descricao": "Acesse benefícios, requerimentos, agendamentos e serviços previdenciários.",
    "categoria": "Previdência",
    "icone": "u-heart",
    "url": "https://meu.inss.gov.br/",
    "fonte": "INSS · Governo Federal",
    "palavras": [
      "aposentadoria",
      "beneficios",
      "pericia"
    ]
  },
  {
    "id": "cnis",
    "titulo": "Extrato Previdenciário (CNIS)",
    "descricao": "Emita o histórico dos vínculos, remunerações e contribuições à Previdência.",
    "categoria": "Previdência",
    "icone": "u-id",
    "url": "https://www.gov.br/pt-br/servicos/emitir-extrato-de-contribuicao-cnis",
    "fonte": "gov.br · INSS",
    "palavras": [
      "extrato",
      "contribuicao",
      "vinculos",
      "previdencia"
    ]
  },
  {
    "id": "emprega",
    "titulo": "Portal Emprega Brasil",
    "descricao": "Encontre serviços de emprego, oportunidades e acesso à sua vida laboral.",
    "categoria": "Emprego",
    "icone": "u-briefcase",
    "url": "https://www.gov.br/pt-br/servicos/acessar-portal-emprega-brasil-2013-trabalhador",
    "fonte": "gov.br · Ministério do Trabalho",
    "palavras": [
      "sine",
      "vagas",
      "empregos",
      "curriculo"
    ]
  },
  {
    "id": "trabalhador",
    "titulo": "Serviços para o trabalhador",
    "descricao": "Veja o catálogo oficial de documentos, qualificação e atendimento ao cidadão.",
    "categoria": "Emprego",
    "icone": "u-grid",
    "url": "https://www.gov.br/pt-br/perfil_usuario/trabalhador",
    "fonte": "gov.br · Serviços ao cidadão",
    "palavras": [
      "trabalho",
      "servicos",
      "vagas",
      "documentos"
    ]
  },
  {
    "id": "mediador",
    "titulo": "Mediador — Convenções Coletivas",
    "descricao": "Consulte instrumentos coletivos registrados no Ministério do Trabalho.",
    "categoria": "Direitos e Justiça",
    "icone": "u-scale",
    "url": "https://mediador.trabalho.gov.br/sistemas/mediador/ConsultarInstColetivo",
    "fonte": "Ministério do Trabalho e Emprego",
    "palavras": [
      "cct",
      "acordo",
      "aditivo",
      "convenções"
    ]
  },
  {
    "id": "trt9",
    "titulo": "TRT da 9ª Região (Paraná)",
    "descricao": "Acesse o Tribunal Regional do Trabalho e consulte informações processuais.",
    "categoria": "Direitos e Justiça",
    "icone": "u-landmark",
    "url": "https://www.trt9.jus.br/portal/secoes.xhtml?id=PESQUISA_PROCESSUAL",
    "fonte": "Justiça do Trabalho · Paraná",
    "palavras": [
      "justica",
      "processos",
      "tribunal",
      "trt"
    ]
  },
  {
    "id": "tst",
    "titulo": "Tribunal Superior do Trabalho",
    "descricao": "Acesse o portal do TST para informações institucionais e jurisprudência.",
    "categoria": "Direitos e Justiça",
    "icone": "u-scale",
    "url": "https://www.tst.jus.br/",
    "fonte": "Justiça do Trabalho · TST",
    "palavras": [
      "tst",
      "tribunal",
      "jurisprudencia"
    ]
  },
  {
    "id": "denuncia",
    "titulo": "Denúncia Trabalhista",
    "descricao": "Veja como registrar irregularidades trabalhistas pelo serviço do MTE.",
    "categoria": "Direitos e Justiça",
    "icone": "u-shield",
    "url": "https://www.gov.br/pt-br/servicos/realizar-denuncia-trabalhista",
    "fonte": "gov.br · Inspeção do Trabalho",
    "palavras": [
      "assedio",
      "irregularidades",
      "denuncia",
      "fiscalizacao"
    ]
  },
  {
    "id": "mte",
    "titulo": "Ministério do Trabalho e Emprego",
    "descricao": "Consulte informações, orientações e canais de atendimento oficiais.",
    "categoria": "Direitos e Justiça",
    "icone": "u-landmark",
    "url": "https://www.gov.br/trabalho-e-emprego/pt-br",
    "fonte": "Governo Federal · MTE",
    "palavras": [
      "trabalho",
      "emprego",
      "ministerio"
    ]
  },
  {
    "id": "rais",
    "titulo": "RAIS — Informações Oficiais",
    "descricao": "Acesse informações sobre a Relação Anual de Informações Sociais.",
    "categoria": "Empregadores",
    "icone": "u-grid",
    "url": "https://www.gov.br/pt-br/servicos/entregar-a-relacao-anual-de-informacoes-sociais",
    "fonte": "gov.br · Ministério do Trabalho",
    "palavras": [
      "rais",
      "declaracao",
      "empregador"
    ]
  },
  {
    "id": "esocial",
    "titulo": "Portal eSocial",
    "descricao": "Informações e serviços para envio de eventos trabalhistas e previdenciários.",
    "categoria": "Empregadores",
    "icone": "u-briefcase",
    "url": "https://www.gov.br/esocial/pt-br",
    "fonte": "Governo Federal · eSocial",
    "palavras": [
      "esocial",
      "folha",
      "empresas",
      "rh"
    ]
  },
  {
    "id": "fgtsdigital",
    "titulo": "FGTS Digital",
    "descricao": "Orientações ao empregador sobre recolhimento e gestão de obrigações do FGTS.",
    "categoria": "Empregadores",
    "icone": "u-wallet",
    "url": "https://www.gov.br/trabalho-e-emprego/pt-br/servicos/empregador/fgtsdigital/",
    "fonte": "Ministério do Trabalho e Emprego",
    "palavras": [
      "fgts",
      "empresa",
      "guia",
      "recolhimento"
    ]
  },
  {
    "id": "falabr",
    "titulo": "Fala.BR — Ouvidoria Pública",
    "descricao": "Registre solicitações, reclamações e pedidos de acesso à informação.",
    "categoria": "Direitos e Justiça",
    "icone": "u-globe",
    "url": "https://falabr.cgu.gov.br/",
    "fonte": "Controladoria-Geral da União",
    "palavras": [
      "ouvidoria",
      "reclamacao",
      "informacao"
    ]
  }
];
