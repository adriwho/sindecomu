# SINDECOMU — Página Sites Úteis

## Instalação na pasta `sindecomu_inicial`

1. Faça uma cópia de segurança da pasta `sindecomu_inicial` no computador.
2. Extraia **sindecomu_sites_uteis_atualizacao.zip**.
3. Copie os arquivos extraídos para dentro da pasta principal `sindecomu_inicial`, mantendo as subpastas.
4. Substitua o arquivo `sites-uteis.html` antigo. **Não substitua** `index.html` nem as demais páginas da sua pasta ao instalar apenas a atualização.
5. Abra `index.html` e clique no atalho **Sites úteis**, ou abra `sites-uteis.html` diretamente.

### Arquivos da atualização

```text
sindecomu_inicial/
├── index.html                   (já existente; não precisa trocar)
├── sites-uteis.html             (novo)
└── assets/
    ├── css/sites-uteis.css     (novo)
    ├── js/sites-uteis.js       (novo)
    └── dados/
        ├── links-uteis.js      (novo; funciona offline abrindo o HTML)
        └── links-uteis.json    (referência para futura API/ADM)
```

O arquivo `sites-uteis.html` também usa `assets/css/site.css`, que já deve existir na pasta após a instalação da versão completa do projeto anterior.

## Arquivos de entrega

- `sindecomu_sites_uteis_preview.html`: prévia **independente** (HTML + CSS + JS embutidos); abra diretamente no navegador.
- `sindecomu_sites_uteis_atualizacao.zip`: só os arquivos novos/alterados.
- `sindecomu_site_com_sites_uteis.zip`: conjunto de páginas acumuladas no projeto, com os arquivos compartilhados.

## Como editar os acessos

A listagem está em `assets/dados/links-uteis.js`. Cada item possui:

- `id`: identificador único;
- `titulo`: nome do serviço;
- `descricao`: explicação curta;
- `categoria`: grupo exibido nos filtros;
- `url`: endereço externo HTTPS;
- `fonte`: entidade responsável;
- `icone`: símbolo da página;
- `destaque`: define exibição na seção inicial (máximo de 3);
- `palavras`: termos auxiliares para a busca.

Atualmente **não há banco de dados** nem cadastro real no ADM para esta seção. A manutenção é feita no arquivo de dados. Uma integração posterior pode disponibilizar uma tabela `links_uteis` e uma API para gestão no servidor.

## Observação sobre a página antiga

O HTML fornecido da página antiga carrega seu conteúdo principal através de um arquivo `conteudoCkeditor.html` em `iframe`, **não incluído no anexo**. Por isso a lista original de links não estava disponível para migração literal. A nova lista é uma curadoria de serviços oficiais relevantes ao trabalhador, e deve ser revisada e aprovada pelo sindicato antes da publicação. Os URLs externos podem mudar com o tempo.

## Comportamentos incluídos

- Mesmo cabeçalho e rodapé das páginas anteriores;
- Barra branca que muda para azul após a capa, com esferas decorativas;
- Busca instantânea sem recarregar a página;
- Seis filtros por assunto e botão para limpar;
- Três links destacados no topo;
- Cartões com ampliação, elevação e transição azul no hover;
- Links externos em novas abas, com `rel="noopener noreferrer"`;
- Menu mobile, botão de legibilidade `A+` e preferência de movimento reduzido.

**Verificações:** 17 registros, 3 destaques, pesquisa e filtro funcionando, sem transbordamento horizontal nas larguras 320, 390 e 1440 pixels.
